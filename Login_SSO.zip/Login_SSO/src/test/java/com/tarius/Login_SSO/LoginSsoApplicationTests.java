package com.tarius.Login_SSO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSsoApplicationTests {

	@Test
	void contextLoads() {
	}

}
