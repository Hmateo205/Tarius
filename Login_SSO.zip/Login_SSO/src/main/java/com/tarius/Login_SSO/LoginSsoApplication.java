package com.tarius.Login_SSO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSsoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginSsoApplication.class, args);
	}

}
