package com.tarius.Login_SSO.Controller;


import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.Model;


@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "index"; // carga templates/index.html
    }

    @GetMapping("/login")
    public String login() {
        return "redirect:/oauth2/authorization/keycloak";
    }


    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal OidcUser user, Model model) {

        if (user != null) {
            model.addAttribute("name", user.getFullName());
        }

        return "dashboard"; // archivo dashboard.html
    }

    @GetMapping("/do-logout")
    public String logout(HttpServletRequest request) throws Exception {

        // Cierra sesión en Spring Security
        request.logout();

        // Logout global de Keycloak (CORRECTO)
        String logoutUrl = "http://localhost:9090/realms/tarius-tita/protocol/openid-connect/logout"
                + "?client_id=app-1"
                + "&post_logout_redirect_uri=http://localhost:8081/";

        return "redirect:" + logoutUrl;
    }

}
