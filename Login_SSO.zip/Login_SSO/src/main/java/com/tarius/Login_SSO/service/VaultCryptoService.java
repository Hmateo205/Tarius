package com.tarius.Login_SSO.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

@Service
public class VaultCryptoService {

    private final RestTemplate restTemplate;

    @Value("${vault.url}")
    private String vaultUrl;

    @Value("${vault.token}")
    private String vaultToken;

    public VaultCryptoService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // 🔐 CIFRAR
    public String encrypt(String plainText) {

        String url = vaultUrl + "/v1/transit/encrypt/app-key";

        String base64 = Base64.getEncoder().encodeToString(plainText.getBytes());

        Map<String, Object> body = Map.of("plaintext", base64);

        var headers = new org.springframework.http.HttpHeaders();
        headers.set("X-Vault-Token", vaultToken);

        var request = new org.springframework.http.HttpEntity<>(body, headers);

        Map<?, ?> response = restTemplate.postForObject(url, request, Map.class);

        return ((Map<?, ?>) response.get("data")).get("ciphertext").toString();
    }

    // 🔓 DESCIFRAR
    public String decrypt(String cipherText) {

        String url = vaultUrl + "/v1/transit/decrypt/app-key";

        Map<String, Object> body = Map.of("ciphertext", cipherText);

        var headers = new org.springframework.http.HttpHeaders();
        headers.set("X-Vault-Token", vaultToken);

        var request = new org.springframework.http.HttpEntity<>(body, headers);

        Map<?, ?> response = restTemplate.postForObject(url, request, Map.class);

        String base64 = ((Map<?, ?>) response.get("data")).get("plaintext").toString();

        return new String(Base64.getDecoder().decode(base64));
    }
}
