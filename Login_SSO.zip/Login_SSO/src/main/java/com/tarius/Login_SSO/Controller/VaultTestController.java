package com.tarius.Login_SSO.Controller;


import com.tarius.Login_SSO.service.VaultCryptoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VaultTestController {

    private final VaultCryptoService cryptoService;

    public VaultTestController(VaultCryptoService cryptoService) {
        this.cryptoService = cryptoService;
    }

    @GetMapping("/vault/test")
    public String test(@RequestParam String value) {

        String encrypted = cryptoService.encrypt(value);
        String decrypted = cryptoService.decrypt(encrypted);

        return """
                ORIGINAL: %s
                ENCRYPTED: %s
                DECRYPTED: %s
                """.formatted(value, encrypted, decrypted);
    }
}
