package com.Tarius.Login_SSO_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSso2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
