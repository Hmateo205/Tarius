package com.Tarius.Login_SSO_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSso2Application {

    public static void main(String[] args) {
        SpringApplication.run(LoginSso2Application.class, args);
    }
}
