package com.Tarius.Login_SSO_2.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index() {
        return "index";
    }


    @GetMapping("/login")
    public String login() {
        return "redirect:/oauth2/authorization/keycloak";
    }


    @GetMapping("/home")
    public String dashboard(@AuthenticationPrincipal OidcUser user, Model model) {

        if (user != null) {
            model.addAttribute("name", user.getFullName());
        }

        return "home"; // archivo dashboard.html
    }

    @GetMapping("/do-logout")
    public String logout(HttpServletRequest request) throws Exception {

        // Cierra sesión en Spring Security
        request.logout();

        // Logout global de Keycloak (CORRECTO)
        String logoutUrl = "http://localhost:9090/realms/tarius-tita/protocol/openid-connect/logout"
                + "?client_id=app-2"
                + "&post_logout_redirect_uri=http://localhost:8082/";

        return "redirect:" + logoutUrl;
    }

}
